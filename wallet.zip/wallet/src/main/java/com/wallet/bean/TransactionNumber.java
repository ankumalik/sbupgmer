package com.wallet.bean;

public class TransactionNumber
{
	 private String transaction_number;
		
		

		public  String getTransaction_Number() {
			return transaction_number;
		}

		public  void setTransaction_Number(String account_number) {
			this.transaction_number = account_number;
		}

		public TransactionNumber(String transaction_number) {
			super();
			this.transaction_number = transaction_number;
		}

		public TransactionNumber() {
			super();
			this.transaction_number = "T"+System.currentTimeMillis();
		}
	}

