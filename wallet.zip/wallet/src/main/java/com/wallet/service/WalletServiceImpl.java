package com.wallet.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.dao.WalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletServiceImpl implements WalletService {

	WalletDao wd = new WalletDaoImpl();
	
	public String createAccount(Customer c, Account a) throws WalletException {
		return wd.createAccount(c,a);
	}

	public boolean validateData(Customer c, Account a) throws WalletException {
		if(validateName(c.getName()) && validateAge(c.getAge()) && validatePhone(c.getPhone()) && validateAccType(a.getAccount_type())) {
			return true;
		}
		return false;
	}
	
	private boolean validateName(String name) throws WalletException{
		if(name.isEmpty() || name==null) {
			throw new WalletException("Name cannot be empty.");
		}
		else {
			if(!name.matches("[A-Z][a-z]{3,}")) {
				throw new WalletException("Name should start with capital letter and contain minimum 3 characters.");
			}
		}
	 return true;
	}
	
	private boolean validateAge(String age) throws WalletException{
		if(age.isEmpty() || age==null) {
			throw new WalletException("Please enter age.");
		}
		else {
			int a;
			try {
				a = Integer.parseInt(age);
				
				if(a<=0) {
					throw new WalletException("Age cannot be less than 0"); 
				}
				else {
					return true;
				}
			} catch (Exception e) {
			    throw new WalletException("Age should be numerical.");	
			}
		}
	  
	}
	
	/*private boolean validateAddress(String address) throws WalletException{
		if(address.isEmpty() || address==null) {
			throw new WalletException("Please enter the address.");
		}
		else {
			if(!address.matches("[A-Za-z][A-Za-z]{2,}")) {
				throw new WalletException("Please enter a valid address.");
			}
		}
	 return true;
	}*/
	
	private boolean validatePhone(String phone) throws WalletException{
		
		if(phone.isEmpty() || phone==null) {
			throw new WalletException("Please enter phone number.");
		}
		else {
			 if(!phone.matches("\\d{10}")) {
				 throw new WalletException("Phone number should be 10 digits.");
			 }
		}
	return true;	
	}

	private boolean validateAccType(String type) throws WalletException{
		if(type.isEmpty() || type==null) {
			throw new WalletException("Account type cannot be empty.");
		}
		else {
			if(type.equalsIgnoreCase("savings")!=true && type.equalsIgnoreCase("current")!=true) {
				throw new WalletException("Account type can be only Savings or Current.");
			}
		}
	 return true;
	}
	
	private boolean validateInitBalance(String balance) throws WalletException{
		if(balance.isEmpty() || balance==null) {
			throw new WalletException("Please enter initial balance.");
		}
		else {
			double a;
			try {
				a = Double.parseDouble(balance);
				
				if(a<=0) {
					throw new WalletException("Balance cannot be less than 0"); 
				}
				else {
					return true;
				}
			} catch (Exception e) {
			    throw new WalletException("Balance should be numerical.");	
			}
		}
	  
	}

	public String showBalance(String acc) throws WalletException {
		
		return wd.showBalance(acc);
	}

	public String deposit(String acc, String amt) throws WalletException {
		try {
		double d = Double.parseDouble(amt);
		if(d<0) {
			throw new WalletException("Amount should be greater than 0");
		}
		}catch (Exception e) {
			throw new WalletException("Enter valid amount.");
		}
		return wd.deposit(acc, amt);
	}

	public String withdraw(String acc, String amt) throws WalletException {
		try {
			double d = Double.parseDouble(amt);
			if(d<0) {
				throw new WalletException("Amount should be greater than 0");
			}
			else {
				String bal = wd.showBalance(acc);
				
				if(bal != null) {
					if(d > Double.parseDouble(bal)) {
						throw new WalletException("Withdrawal amount cannot be greater than balance amount.");
					}
					else {
						return wd.withdraw(acc, amt);
					}
				}
				else {
					return null;
				}
			}
			}catch (Exception e) {
				throw new WalletException(e.getMessage());
			}
		
	}

	public boolean checkAccountExist(String acc) throws WalletException {
		
		return wd.checkAccountExist(acc);
	}

	public String fundTransfer(String acc, String amt, String rAcc) throws WalletException {
		String sender = wd.showBalance(acc);
		String receiver = wd.showBalance(rAcc);
		
		if(sender == null) {
			throw new WalletException("Sender account doesn't exists.");
		}
		else if(receiver == null) {
			throw new WalletException("Receiver account doesn't exists.");
		}
		
		try {
			Double amount = Double.parseDouble(amt);
			if(amount > Double.parseDouble(sender)) {
				throw new WalletException("Amount to be transferred is more than balance in the account.");
			}
			else {
				return wd.fundTransfer(acc, amt, rAcc);
			}
		} catch (Exception e) {
			throw new WalletException("Error: "+e.getMessage());
		}
	 
	}

	@Override
	public String dwTransaction(String status, String transaction_type, String account, LocalDate date, String amount)
			throws WalletException 
	{
		return wd.dwTransaction(status, transaction_type, account, date, amount); 
	}

	@Override
	public String transferTransaction(String status, String transaction_type, String senderAcc, String receiverAcc,
			LocalDate date, String amount) throws WalletException {
		return wd.transferTransaction(status, transaction_type, senderAcc, receiverAcc, date, amount); 
	}

	@Override
	public HashMap<String, Transaction> printTransaction(String acc) throws WalletException {
		// TODO Auto-generated method stub
		return wd.printTransaction(acc);
	}
	
}
