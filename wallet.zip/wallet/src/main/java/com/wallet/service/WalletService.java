package com.wallet.service;

import java.time.LocalDate;
import java.util.HashMap;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.exception.WalletException;

public interface WalletService {

	public String createAccount(Customer c, Account a) throws WalletException;
	public boolean validateData(Customer c, Account a) throws WalletException;
	public String showBalance(String acc) throws WalletException;
	public String deposit(String acc, String amt) throws WalletException;
	public String withdraw(String acc, String amt) throws WalletException;
	public String fundTransfer(String acc, String amt, String rAcc) throws WalletException;
	public boolean checkAccountExist(String acc) throws WalletException;
	public String dwTransaction(String status, String transaction_type, String account, LocalDate date, String amount) throws WalletException;
	public String transferTransaction(String status, String transaction_type, String senderAcc, String receiverAcc, LocalDate date, String amount) throws WalletException;
	public HashMap<String,Transaction> printTransaction(String acc) throws WalletException; 
	
}
